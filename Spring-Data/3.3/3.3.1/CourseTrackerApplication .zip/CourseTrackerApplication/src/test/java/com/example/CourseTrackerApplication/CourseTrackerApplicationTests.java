package com.example.CourseTrackerApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
