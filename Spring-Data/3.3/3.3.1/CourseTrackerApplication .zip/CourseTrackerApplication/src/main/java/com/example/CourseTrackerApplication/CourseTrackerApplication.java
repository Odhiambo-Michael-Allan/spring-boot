package com.example.CourseTrackerApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseTrackerApplication.class, args);
	}

}
